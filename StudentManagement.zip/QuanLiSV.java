package QuanLiSinhVien;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Vector;



public class QuanLiSV {
	static Vector<SinhVien> danhsachsv = new Vector<SinhVien>();
	static Scanner sc = new Scanner(System.in);

	//Nhap thong tin sinh vien
	public void input() {
		System.out.println(" Nhap so luong sinh vien: ");
		int slsv  = sc.nextInt();
		sc.nextLine();
		SinhVien[] sinhvien = new SinhVien[slsv];
		for (int i = 0; i < slsv; i++) {
			System.out.println(" Nhap thong tin sinh vien thu " + (i + 1) + " :");
			System.out.print(" ID: ");
			String id = sc.nextLine();
			System.out.print(" Ten: ");
			String name = sc.nextLine();
			System.out.print(" So mon da hoc: ");
			int n = Integer.parseInt(sc.nextLine());
			HocPhan[] dshocphan = new HocPhan[n];
			for (int j = 0; j < n; j++) {
				System.out.println(" Nhap thong tin hoc phan thu " + (j + 1) + " :");
				System.out.print(" ID: ");
				String idhp = (sc.nextLine());
				System.out.print(" Ten hoc phan: ");
				String tenhp = sc.nextLine();
				System.out.print(" So tin chi: ");
				int sotc = Integer.parseInt(sc.nextLine());
				System.out.print(" Diem: ");
				float diemhp = Float.parseFloat(sc.nextLine());
				dshocphan[j] = new HocPhan(idhp, tenhp, sotc, diemhp);
			}
			sinhvien[i] = new SinhVien(id, name, n, dshocphan);
			danhsachsv.add(sinhvien[i]);
		}
	}

	//Xem danh sach sinh vien
	public void xemdanhsachsv() {
		System.out.println("  Thong tin danh sach sinh vien");
		for (SinhVien sv : danhsachsv) {
			System.out.println("ID="+sv.getId()+", Ten="+sv.getName()+", Diem trung binh="+sv.avg());
		}
	}

	//Sap xep danh sach sinh vien tang dan theo diem trung binh
	public void sapxeptheodiemtbtangdan() {
		Collections.sort(danhsachsv, new Comparator<SinhVien>() {
			public int compare(SinhVien sv1, SinhVien sv2) {
				Float a = Float.valueOf(sv1.avg());
				Float b = Float.valueOf(sv2.avg());
				return a.compareTo(b);
			}
		});
	}

	//Tim sinh vien theo ten
	public void timsvtheoten() {
		System.out.print("Nhap ten sinh vien can tim: ");
		sc.nextLine();
		String namesv = sc.nextLine();
		System.out.println("\n--Thong tin tim kiem duoc--");
		for (SinhVien sv : danhsachsv) {
			if (sv.getName().equals(namesv)) {
				System.out.println("ID="+sv.getId()+", Ten="+sv.getName()+", Diem trung binh="+sv.avg());
			}
		}
	}
	
	//Hien thi danh sach sinh vien hoc cung mot hoc phan
	public void danhsachsvhoccunghp() {
		System.out.println(" Nhap ten hoc phan: ");
		sc.nextLine();
		String namehp=sc.nextLine();
		System.out.println(" Danh sach sinh vien co cung hoc phan " + namehp + " :" );
		for (SinhVien sv : danhsachsv) {
			for(int i=0; i<sv.getN();i++) {
				if (sv.getList()[i].getTenhp().equals(namehp)) {
					System.out.println("ID="+sv.getId()+", Ten="+sv.getName()+", Diem trung binh="+sv.avg());	
				}
			}
			
		}
	}
	
	//Hien thi danh sach sinh vien giam dan theo so luong tin chi
	public void danhsachsvgiamtheosotc() {
		Collections.sort(danhsachsv, new Comparator<SinhVien>() {
			public int compare(SinhVien sv1, SinhVien sv2) {
				Integer a= Integer.valueOf(sv1.Stc());
				Integer b= Integer.valueOf(sv2.Stc());
				return b.compareTo(a);
			}
		});
	}
	
	//Hien thi sinh vien co diem cao nhat cua mot hoc phan
	public void svdiemcaonhatcuahp() {
		Collections.sort(danhsachsv, new Comparator<SinhVien>() {
			public int compare(SinhVien sv1, SinhVien sv2) {
				Float a = Float.valueOf(sv1.avg());
				Float b = Float.valueOf(sv2.avg());
				return  b.compareTo(a);
			}
		});	
		
		System.out.println(" Nhap ten hoc phan: ");
		sc.nextLine();
		String tenhp = sc.nextLine();
		System.out.println(" Danh sach sinh vien co diem cao nhat cua hoc phan " + tenhp);
		float temp = 0;
		int index = 0;
		for (int i=0; i< danhsachsv.size(); i++) {
			  
			 //xuat thong tin mot sinh vien co diem cao nhat 
			 for (int j=0; j<danhsachsv.get(i).getN(); j++) {
				 if (danhsachsv.get(i).getList()[j].getTenhp().equals(tenhp) == true) {
					 System.out.println("ID="+danhsachsv.get(i).getId()+", Ten="+danhsachsv.get(i).getName()+", Diem trung binh="+danhsachsv.get(i).avg());
					 temp = danhsachsv.get(i).avg();
					 index = i;
					 break;
				 }
			 }
		 }
		
			//duyet lai list sinh vien
			 for (int jj=index+1; jj<danhsachsv.size(); jj++) {
					//xuat thong tin sinh vien co diem cao bang sinh vien thu nhat
					for (int k=0; k<danhsachsv.get(jj).getN(); k++) {
						 if (danhsachsv.get(jj).getList()[k].getTenhp().equals(tenhp) == true && danhsachsv.get(jj).avg() == temp) {
							 System.out.println("ID="+danhsachsv.get(jj).getId()+", Ten="+danhsachsv.get(jj).getName()+", Diem trung binh="+danhsachsv.get(jj).avg());
						 }
					}
					break;
				}
	}
	

		
	

	public static void main(String[] args) {
		QuanLiSV qlsv = new QuanLiSV();
		
		while(true) {
			System.out.println("*-CHUONG TRINH QUAN LY SINH VIEN-*");
			System.out.println("*-Chuc nang chinh chuong trinh-*");
			System.out.println("  1. Nhap danh sach sinh vien   ");
			System.out.println("  2. Xem danh sach sinh vien   ");
			System.out.println("  3. Sap xep sach sinh vien tang dan diem trung binh   ");
			System.out.println("  4. Tim sinh vien theo ten   ");
			System.out.println("  5. Danh sach sinh vien hoc cung mot hoc phan  ");
			System.out.println("  6. Danh sach sinh vien giam dan theo so tin chi   ");
			System.out.println("  7. Hien thi sinh vien co diem cao nhat cua mot hoc phan   ");
			System.out.println("  0. Thoat   ");
			System.out.println("  -------------");
			
			System.out.print(" Nhap mot so de chon chuc nang: ");
			int num = sc.nextInt();
			
			switch(num) {
				case 1:
					qlsv.input();
					System.out.println("\n--------\n");
					break;	
				case 2:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else 
						qlsv.xemdanhsachsv();
					System.out.println("\n--------\n");
					break;
				case 3:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else {
						qlsv.sapxeptheodiemtbtangdan();
						qlsv.xemdanhsachsv();
					}
					System.out.println("\n--------\n");
					break;
				case 4:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else 
						qlsv.timsvtheoten();;
					System.out.println("\n--------\n");
					break;
				case 5:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else 
						qlsv.danhsachsvhoccunghp();
					System.out.println("\n--------\n");
					break;
				case 6:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else {
						qlsv.danhsachsvgiamtheosotc();
						qlsv.xemdanhsachsv();
					}
					System.out.println("\n--------\n");
					break;
				case 7:
					if(danhsachsv.size()==0)
						System.out.println(" Nhap danh sach sinh vien truoc !!!");
					else 
						qlsv.svdiemcaonhatcuahp();
					System.out.println("\n--------\n");
					break;
				case 0:
					System.out.print("----  Chuong trinh ket thuc----- ");
					return;
				default:
					System.out.println(" Chon mot trong cac chuc nang tu 0 den 7");
					System.out.println("\n--------\n");
					break;
			}
		}
		
		
	}
	
	

}


